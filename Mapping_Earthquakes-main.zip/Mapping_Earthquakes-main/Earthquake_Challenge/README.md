# Earthquake_Analysis
### Purpose
The purpose of the earthquake analysis is to see the earthquake data in relation to the tectonic plates’ location on the earth, all the earthquakes with a magnitude greater than 4.5 on the map. 

## Summary of Earthquake_Analysis Results

### Deliverable 1 Tectonic Plates and Earthquakes
![Deliverable1.png](https://github.com/gracemarshall/Mapping_Earthquakes/blob/a046ff791f0c97d7d13024a7a30b78b86c3874ec/Earthquake_Challenge/images/Deliverable1.png)

### Deliverable 2 Magnitude of Major Earthquakes
![Deliverable2a.png](https://github.com/gracemarshall/Mapping_Earthquakes/blob/a046ff791f0c97d7d13024a7a30b78b86c3874ec/Earthquake_Challenge/images/Deliverable2a.png)

### Deliverable 3 Add an Additional Map 
![Deliverable3.png](https://github.com/gracemarshall/Mapping_Earthquakes/blob/a046ff791f0c97d7d13024a7a30b78b86c3874ec/Earthquake_Challenge/images//Deliverable3.png)